from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Order, Review

bp = Blueprint('manager', __name__)

def manager_required(func):
    from functools import wraps
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated or (not current_user.is_manager() and not current_user.is_admin()):
            flash('Доступ запрещён. Требуются права менеджера или администратора.', 'danger')
            return redirect(url_for('main.index'))
        return func(*args, **kwargs)
    return decorated_view

@bp.route('/dashboard')
@login_required
@manager_required
def dashboard():
    new_orders = Order.query.filter_by(status='new').order_by(Order.created_at.desc()).limit(5).all()
    new_reviews = Review.query.order_by(Review.created_at.desc()).limit(5).all()
    return render_template('manager/dashboard.html', new_orders=new_orders, new_reviews=new_reviews)

@bp.route('/orders')
@login_required
@manager_required
def orders():
    all_orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('manager/orders.html', orders=all_orders)

@bp.route('/orders/<int:id>')
@login_required
@manager_required
def order_detail(id):
    order = Order.query.get_or_404(id)
    statuses = [
        ('new', 'Новый'),
        ('preparing', 'Готовится'),
        ('ready', 'Готов'),
        ('delivered', 'Доставлен'),
        ('cancelled', 'Отменён')
    ]
    return render_template('manager/order_detail.html', order=order, statuses=statuses)

@bp.route('/orders/update_status/<int:id>', methods=['POST'])
@login_required
@manager_required
def update_order_status(id):
    order = Order.query.get_or_404(id)
    new_status = request.form.get('status')
    if new_status:
        order.status = new_status
        db.session.commit()
        flash('Статус заказа обновлён.', 'success')
    return redirect(url_for('manager.order_detail', id=id))

@bp.route('/reviews')
@login_required
@manager_required
def reviews():
    all_reviews = Review.query.order_by(Review.created_at.desc()).all()
    return render_template('manager/reviews.html', reviews=all_reviews)

@bp.route('/reviews/delete/<int:id>', methods=['POST'])
@login_required
@manager_required
def delete_review(id):
    review = Review.query.get_or_404(id)
    db.session.delete(review)
    db.session.commit()
    return jsonify({'success': True})
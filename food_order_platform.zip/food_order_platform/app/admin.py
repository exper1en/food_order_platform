from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Restaurant, Dish, Order, User
from app.forms import RestaurantForm, DishForm

bp = Blueprint('admin', __name__)

def admin_required(func):
    from functools import wraps
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash('Доступ запрещён. Требуются права администратора.', 'danger')
            return redirect(url_for('main.index'))
        return func(*args, **kwargs)
    return decorated_view

@bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    restaurants_count = Restaurant.query.count()
    dishes_count = Dish.query.count()
    orders_count = Order.query.count()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    return render_template('admin/dashboard.html',
                           restaurants_count=restaurants_count,
                           dishes_count=dishes_count,
                           orders_count=orders_count,
                           recent_orders=recent_orders)

# --- Рестораны ---
@bp.route('/restaurants')
@login_required
@admin_required
def restaurants():
    restaurants = Restaurant.query.all()
    return render_template('admin/restaurants.html', restaurants=restaurants)

@bp.route('/restaurants/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_restaurant():
    form = RestaurantForm()
    if form.validate_on_submit():
        restaurant = Restaurant(
            name=form.name.data,
            description=form.description.data,
            address=form.address.data,
            phone=form.phone.data,
            image_url=form.image_url.data,
            is_active=form.is_active.data
        )
        db.session.add(restaurant)
        db.session.commit()
        flash('Ресторан успешно добавлен!', 'success')
        return redirect(url_for('admin.restaurants'))
    return render_template('admin/add_restaurant.html', form=form)

@bp.route('/restaurants/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_restaurant(id):
    restaurant = Restaurant.query.get_or_404(id)
    form = RestaurantForm(obj=restaurant)
    if form.validate_on_submit():
        form.populate_obj(restaurant)
        db.session.commit()
        flash('Ресторан обновлён!', 'success')
        return redirect(url_for('admin.restaurants'))
    return render_template('admin/edit_restaurant.html', form=form, restaurant=restaurant)

@bp.route('/restaurants/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_restaurant(id):
    restaurant = Restaurant.query.get_or_404(id)
    db.session.delete(restaurant)
    db.session.commit()
    return jsonify({'success': True})

# --- Блюда ---
@bp.route('/dishes')
@login_required
@admin_required
def dishes():
    dishes = Dish.query.all()
    return render_template('admin/dishes.html', dishes=dishes)

@bp.route('/dishes/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_dish():
    form = DishForm()
    if form.validate_on_submit():
        dish = Dish(
            name=form.name.data,
            description=form.description.data,
            price=form.price.data,
            image_url=form.image_url.data,
            is_available=form.is_available.data,
            restaurant_id=form.restaurant_id.data
        )
        db.session.add(dish)
        db.session.commit()
        flash('Блюдо добавлено!', 'success')
        return redirect(url_for('admin.dishes'))
    return render_template('admin/add_dish.html', form=form)

@bp.route('/dishes/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_dish(id):
    dish = Dish.query.get_or_404(id)
    form = DishForm(obj=dish)
    if form.validate_on_submit():
        form.populate_obj(dish)
        db.session.commit()
        flash('Блюдо обновлено!', 'success')
        return redirect(url_for('admin.dishes'))
    return render_template('admin/edit_dish.html', form=form, dish=dish)

@bp.route('/dishes/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_dish(id):
    dish = Dish.query.get_or_404(id)
    db.session.delete(dish)
    db.session.commit()
    return jsonify({'success': True})

# --- Заказы ---
@bp.route('/orders')
@login_required
@admin_required
def orders():
    all_orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders.html', orders=all_orders)

@bp.route('/orders/<int:id>')
@login_required
@admin_required
def order_detail(id):
    order = Order.query.get_or_404(id)
    statuses = [
        ('new', 'Новый'),
        ('preparing', 'Готовится'),
        ('ready', 'Готов'),
        ('delivered', 'Доставлен'),
        ('cancelled', 'Отменён')
    ]
    return render_template('admin/order_detail.html', order=order, statuses=statuses)

@bp.route('/orders/update_status/<int:id>', methods=['POST'])
@login_required
@admin_required
def update_order_status(id):
    order = Order.query.get_or_404(id)
    new_status = request.form.get('status')
    if new_status:
        order.status = new_status
        db.session.commit()
        flash('Статус заказа обновлён.', 'success')
    return redirect(url_for('admin.order_detail', id=id))
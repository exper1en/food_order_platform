from flask import Blueprint, render_template, request
from app.models import Restaurant, Dish
from app.forms import SearchForm

bp = Blueprint('main', __name__)


@bp.route('/')
def index():
    form = SearchForm()
    query = request.args.get('query', '')
    page = request.args.get('page', 1, type=int)

    # Популярные блюда (по количеству в заказах)
    popular_dishes = Dish.query.filter_by(is_available=True).order_by(Dish.id.desc()).limit(4).all()

    # Поиск ресторанов
    restaurants_query = Restaurant.query.filter_by(is_active=True)
    if query:
        restaurants_query = restaurants_query.filter(
            Restaurant.name.contains(query) | Restaurant.description.contains(query))
    restaurants = restaurants_query.paginate(page=page, per_page=6)

    return render_template('index.html',
                           form=form,
                           query=query,
                           popular_dishes=popular_dishes,
                           restaurants=restaurants)
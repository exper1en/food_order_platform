from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, FloatField, IntegerField, SelectField, BooleanField
from wtforms.validators import DataRequired, Email, EqualTo, Length, NumberRange, Optional, ValidationError
from app.models import User, Restaurant

class RegistrationForm(FlaskForm):
    username = StringField('Имя пользователя', validators=[DataRequired(), Length(min=2, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Пароль', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Повторите пароль', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Зарегистрироваться')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Это имя пользователя уже занято.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Этот email уже зарегистрирован.')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')

class RestaurantForm(FlaskForm):
    name = StringField('Название ресторана', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Описание', validators=[Optional()])
    address = StringField('Адрес', validators=[Optional(), Length(max=200)])
    phone = StringField('Телефон', validators=[Optional(), Length(max=20)])
    image_url = StringField('URL изображения', validators=[Optional(), Length(max=200)])
    is_active = BooleanField('Активен', default=True)
    submit = SubmitField('Сохранить')

class DishForm(FlaskForm):
    name = StringField('Название блюда', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Описание', validators=[Optional()])
    price = FloatField('Цена', validators=[DataRequired(), NumberRange(min=0.01)])
    image_url = StringField('URL изображения', validators=[Optional(), Length(max=200)])
    is_available = BooleanField('Доступно для заказа', default=True)
    restaurant_id = SelectField('Ресторан', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Сохранить')

    def __init__(self, *args, **kwargs):
        super(DishForm, self).__init__(*args, **kwargs)
        self.restaurant_id.choices = [(r.id, r.name) for r in Restaurant.query.filter_by(is_active=True).all()]

class AddToCartForm(FlaskForm):
    quantity = IntegerField('Количество', validators=[DataRequired(), NumberRange(min=1, max=99)], default=1)
    submit = SubmitField('В корзину')

class CheckoutForm(FlaskForm):
    delivery_address = StringField('Адрес доставки', validators=[DataRequired(), Length(max=200)])
    contact_phone = StringField('Контактный телефон', validators=[DataRequired(), Length(max=20)])
    comment = TextAreaField('Комментарий к заказу', validators=[Optional()])
    submit = SubmitField('Оформить заказ')

class ReviewForm(FlaskForm):
    rating = SelectField('Оценка', choices=[(1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5')], validators=[DataRequired()], coerce=int)
    comment = TextAreaField('Комментарий', validators=[Optional()])
    submit = SubmitField('Оставить отзыв')

class SearchForm(FlaskForm):
    query = StringField('Поиск', validators=[Optional()])
    submit = SubmitField('Найти')
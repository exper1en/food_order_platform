from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Restaurant, Dish, Order, OrderItem, Review, cart_items
from app.forms import CheckoutForm, ReviewForm

bp = Blueprint('guest', __name__)


@bp.route('/restaurant/<int:id>')
def restaurant_detail(id):
    restaurant = Restaurant.query.get_or_404(id)
    dishes = Dish.query.filter_by(restaurant_id=id, is_available=True).all()
    reviews = Review.query.filter_by(restaurant_id=id).order_by(Review.created_at.desc()).all()
    form = ReviewForm()
    return render_template('guest/menu.html', restaurant=restaurant, dishes=dishes, reviews=reviews, review_form=form)


@bp.route('/cart')
@login_required
def cart():
    # Получаем все блюда в корзине с количеством
    cart_data = db.session.query(Dish, cart_items.c.quantity).join(cart_items).filter(
        cart_items.c.user_id == current_user.id).all()
    cart_items_list = [{'dish': dish, 'quantity': qty} for dish, qty in cart_data]
    total = sum(item['dish'].price * item['quantity'] for item in cart_items_list)
    return render_template('guest/cart.html', cart_items=cart_items_list, total=total)


@bp.route('/cart/add/<int:dish_id>', methods=['POST'])
@login_required
def add_to_cart(dish_id):
    dish = Dish.query.get_or_404(dish_id)
    # Проверяем, есть ли уже в корзине
    stmt = cart_items.select().where(cart_items.c.user_id == current_user.id, cart_items.c.dish_id == dish_id)
    existing = db.session.execute(stmt).first()
    if existing:
        db.session.execute(cart_items.update().where(
            cart_items.c.user_id == current_user.id,
            cart_items.c.dish_id == dish_id
        ).values(quantity=cart_items.c.quantity + 1))
    else:
        db.session.execute(cart_items.insert().values(user_id=current_user.id, dish_id=dish_id, quantity=1))
    db.session.commit()
    return jsonify({'success': True, 'message': f'{dish.name} добавлено в корзину'})


@bp.route('/cart/update/<int:dish_id>', methods=['POST'])
@login_required
def update_cart(dish_id):
    data = request.get_json()
    delta = data.get('delta', 0)
    stmt = cart_items.select().where(cart_items.c.user_id == current_user.id, cart_items.c.dish_id == dish_id)
    existing = db.session.execute(stmt).first()
    if existing:
        new_qty = existing.quantity + delta
        if new_qty <= 0:
            db.session.execute(cart_items.delete().where(
                cart_items.c.user_id == current_user.id,
                cart_items.c.dish_id == dish_id
            ))
        else:
            db.session.execute(cart_items.update().where(
                cart_items.c.user_id == current_user.id,
                cart_items.c.dish_id == dish_id
            ).values(quantity=new_qty))
        db.session.commit()
    return jsonify({'success': True})


@bp.route('/cart/remove/<int:dish_id>', methods=['POST'])
@login_required
def remove_from_cart(dish_id):
    db.session.execute(cart_items.delete().where(
        cart_items.c.user_id == current_user.id,
        cart_items.c.dish_id == dish_id
    ))
    db.session.commit()
    return jsonify({'success': True})


@bp.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    # Получаем корзину
    cart_data = db.session.query(Dish, cart_items.c.quantity).join(cart_items).filter(
        cart_items.c.user_id == current_user.id).all()
    if not cart_data:
        flash('Корзина пуста', 'warning')
        return redirect(url_for('guest.cart'))

    # Группируем по ресторану (все блюда должны быть из одного ресторана)
    restaurants = set(dish.restaurant_id for dish, _ in cart_data)
    if len(restaurants) > 1:
        flash('В корзине блюда из разных ресторанов. Оформите отдельные заказы.', 'danger')
        return redirect(url_for('guest.cart'))

    restaurant_id = restaurants.pop()
    form = CheckoutForm()
    total = sum(dish.price * qty for dish, qty in cart_data)

    if form.validate_on_submit():
        # Создаём заказ
        order = Order(
            user_id=current_user.id,
            restaurant_id=restaurant_id,
            delivery_address=form.delivery_address.data,
            contact_phone=form.contact_phone.data,
            comment=form.comment.data
        )
        db.session.add(order)
        db.session.flush()  # получаем order.id

        for dish, qty in cart_data:
            item = OrderItem(order_id=order.id, dish_id=dish.id, quantity=qty, price=dish.price)
            db.session.add(item)

        order.calculate_total()
        # Очищаем корзину
        db.session.execute(cart_items.delete().where(cart_items.c.user_id == current_user.id))
        db.session.commit()

        flash('Заказ успешно оформлен!', 'success')
        return redirect(url_for('guest.order_confirmation', order_id=order.id))

    return render_template('guest/checkout.html', form=form,
                           cart_items=[{'dish': d, 'quantity': q} for d, q in cart_data], total=total)


@bp.route('/order/confirmation/<int:order_id>')
@login_required
def order_confirmation(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('Доступ запрещён', 'danger')
        return redirect(url_for('main.index'))
    return render_template('guest/order_confirmation.html', order=order)


@bp.route('/my-orders')
@login_required
def my_orders():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('guest/my_orders.html', orders=orders)


@bp.route('/add_review/<int:restaurant_id>', methods=['POST'])
@login_required
def add_review(restaurant_id):
    restaurant = Restaurant.query.get_or_404(restaurant_id)
    form = ReviewForm()
    if form.validate_on_submit():
        # Проверяем, не оставлял ли уже отзыв
        existing = Review.query.filter_by(user_id=current_user.id, restaurant_id=restaurant_id).first()
        if existing:
            flash('Вы уже оставляли отзыв об этом ресторане.', 'warning')
        else:
            review = Review(
                user_id=current_user.id,
                restaurant_id=restaurant_id,
                rating=form.rating.data,
                comment=form.comment.data
            )
            db.session.add(review)
            db.session.commit()
            flash('Спасибо за отзыв!', 'success')
    return redirect(url_for('guest.restaurant_detail', id=restaurant_id))

@bp.route('/cart/count')
@login_required
def cart_count():
    stmt = db.session.query(cart_items.c.quantity).filter(cart_items.c.user_id == current_user.id)
    count = sum(qty for (qty,) in stmt.all())
    return jsonify({'count': count})
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Пожалуйста, войдите для доступа к этой странице.'

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)

    @app.cli.command('init-db')
    def init_db_command():
        """Инициализация базы данных и добавление тестовых данных."""
        db.create_all()
        # Здесь код заполнения, аналогичный выше
        print('База данных инициализирована.')

    from app.main import bp as main_bp
    app.register_blueprint(main_bp)

    from app.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')

    from app.admin import bp as admin_bp
    app.register_blueprint(admin_bp, url_prefix='/admin')

    from app.manager import bp as manager_bp
    app.register_blueprint(manager_bp, url_prefix='/manager')

    from app.guest import bp as guest_bp
    app.register_blueprint(guest_bp, url_prefix='/guest')

    return app

from app import models

from app import create_app, db
from app.models import User, Restaurant, Dish

app = create_app()
with app.app_context():
    # Удаляем все существующие записи (опционально, если хотите чистую базу)
    # Если хотите сохранить существующие данные, закомментируйте следующие строки
    db.drop_all()
    db.create_all()

    # Создаём пользователей
    admin = User(username='admin', email='admin@food.ru', role='admin')
    admin.set_password('admin123')
    db.session.add(admin)

    manager = User(username='manager', email='manager@food.ru', role='manager')
    manager.set_password('manager123')
    db.session.add(manager)

    guest = User(username='user', email='user@food.ru', role='guest')
    guest.set_password('user123')
    db.session.add(guest)

    db.session.commit()

    # Создаём рестораны
    restaurants = [
        Restaurant(
            name='Пицца Миа',
            description='Лучшая итальянская пицца в городе. Дровяная печь, свежие ингредиенты.',
            address='ул. Вкусная, 15',
            phone='+7 (999) 123-45-67',
            image_url='https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400',
            is_active=True
        ),
        Restaurant(
            name='Суши Wok',
            description='Японская и паназиатская кухня. Роллы, суши, лапша wok.',
            address='пр. Центральный, 42',
            phone='+7 (999) 234-56-78',
            image_url='https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=400',
            is_active=True
        ),
        Restaurant(
            name='Бургер Кингс',
            description='Сочные бургеры, картофель фри и молочные коктейли.',
            address='ул. Молодёжная, 8',
            phone='+7 (999) 345-67-89',
            image_url='https://images.unsplash.com/photo-1550547660-d9450f859349?w=400',
            is_active=True
        ),
    ]
    for r in restaurants:
        db.session.add(r)
    db.session.commit()

    # Получаем ID ресторанов после сохранения
    pizza_place = Restaurant.query.filter_by(name='Пицца Миа').first()
    sushi_place = Restaurant.query.filter_by(name='Суши Wok').first()
    burger_place = Restaurant.query.filter_by(name='Бургер Кингс').first()

    dishes = [
        Dish(name='Маргарита', description='Томатный соус, моцарелла, базилик', price=450,
             restaurant_id=pizza_place.id),
        Dish(name='Пепперони', description='Пепперони, моцарелла, томатный соус', price=550,
             restaurant_id=pizza_place.id),
        Dish(name='Четыре сыра', description='Сливочный соус, моцарелла, пармезан, горгонзола, фета', price=650,
             restaurant_id=pizza_place.id),

        Dish(name='Филадельфия ролл', description='Лосось, сливочный сыр, огурец', price=390,
             restaurant_id=sushi_place.id),
        Dish(name='Калифорния ролл', description='Краб, авокадо, огурец, икра тобико', price=420,
             restaurant_id=sushi_place.id),
        Dish(name='Удон с курицей', description='Пшеничная лапша, курица, овощи, соус терияки', price=380,
             restaurant_id=sushi_place.id),

        Dish(name='Чизбургер', description='Говяжья котлета, сыр чеддер, салат, помидор, соус', price=320,
             restaurant_id=burger_place.id),
        Dish(name='Бекон бургер', description='Говяжья котлета, бекон, сыр, лук фри', price=380,
             restaurant_id=burger_place.id),
        Dish(name='Картофель фри', description='Хрустящий картофель с солью', price=120, restaurant_id=burger_place.id),
    ]
    for d in dishes:
        db.session.add(d)
    db.session.commit()

    print("Тестовые данные успешно добавлены!")